package com.daugherty.presentation.akka;

/**
 * Created by MMJ1112 on 11/14/2017.
 */
public class SetRequest {

    private final String key;
    private final String value;

    public SetRequest(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }
}
