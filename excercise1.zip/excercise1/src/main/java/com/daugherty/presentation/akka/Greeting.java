package com.daugherty.presentation.akka;

/**
 * Created by MMJ1112 on 11/14/2017.
 */
public class Greeting {

    public String getGreeting() {
        return greeting;
    }

    private final String greeting;

    public Greeting(String greeting){
        this.greeting=greeting;
    }

}
