package com.daugherty.presentation.akka;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.event.Logging;
import akka.event.LoggingAdapter;

/**
 * Created by MMJ1112 on 11/14/2017.
 */
public class SecondActor extends AbstractActor {

    final LoggingAdapter log = Logging.getLogger(getContext().getSystem(), this);

    @Override
    public Receive createReceive() {
        return null;
    }
}
