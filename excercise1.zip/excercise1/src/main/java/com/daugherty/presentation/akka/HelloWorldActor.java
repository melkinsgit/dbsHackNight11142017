package com.daugherty.presentation.akka;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;
import akka.event.Logging;
import akka.event.LoggingAdapter;

import java.util.HashMap;

/**
 * Created by MMJ1112 on 11/14/2017.
 */
public class HelloWorldActor extends AbstractActor {

    protected LoggingAdapter log = Logging.getLogger(getContext().getSystem(),this);
    protected HashMap<String,String> map =  new HashMap<>();

    @Override
    public Receive createReceive() {
        return null;
    }
}


