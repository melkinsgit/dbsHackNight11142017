package com.daugherty.excercise2.messages;

/**
 * Created by MMJ1112 on 11/14/2017.
 */
public class WaitingRoomFull {
}
