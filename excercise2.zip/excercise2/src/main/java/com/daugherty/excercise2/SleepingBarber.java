package com.daugherty.excercise2;

/**
 * Created by MMJ1112 on 11/14/2017.
 */
import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import com.daugherty.excercise2.actor.BarberShop;
import com.daugherty.excercise2.actor.Customer;
import com.daugherty.excercise2.messages.CustomerWalkIn;

public class SleepingBarber {
    public static void main(String[] args) {
        try {
            int numberOfChair = Integer.parseInt(args[0]);
            int numberOfCustomer = Integer.parseInt(args[1]);

            ActorSystem system = ActorSystem.create("sleeping-barber");
            ActorRef barberShop = system.actorOf(Props.create(BarberShop.class, numberOfChair));

            for (int i = 0; i < numberOfCustomer; i++) {
                ActorRef customer = system.actorOf(Props.create(Customer.class, "customer " + i),"customer_" + i);
                barberShop.tell(new CustomerWalkIn(customer), null);
                try {
                    Thread.sleep(2000);
                } catch (Exception ex) {
                }
            }
        } catch (Exception ex) {
            System.err.println("Invalid Argument.");
            ex.printStackTrace();
        }

    }
}
