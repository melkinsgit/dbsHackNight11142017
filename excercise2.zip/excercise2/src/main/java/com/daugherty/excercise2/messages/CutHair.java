package com.daugherty.excercise2.messages;

/**
 * Created by MMJ1112 on 11/14/2017.
 */
import akka.actor.ActorRef;


public class CutHair  {
    private ActorRef customer;

    public CutHair(ActorRef cus) {
        customer = cus;
    }

    public ActorRef getCustomer() {
        return customer;
    }
}

