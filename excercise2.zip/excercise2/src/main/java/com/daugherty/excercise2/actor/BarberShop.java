package com.daugherty.excercise2.actor;

/**
 * Created by MMJ1112 on 11/14/2017.
 */
import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import com.daugherty.excercise2.FixedQueue;
import com.daugherty.excercise2.messages.*;

import java.util.Optional;

public class BarberShop extends AbstractActor {

    private LoggingAdapter log = Logging.getLogger(getContext().getSystem(), this);

    private int numberOfWaitingChair;
    private FixedQueue<ActorRef> waitingRoom;
    private Optional<ActorRef> chair = Optional.empty();
    private ActorRef barber;

    public BarberShop(int maxChair) {
        numberOfWaitingChair = maxChair;
        waitingRoom = new FixedQueue<>(numberOfWaitingChair);
        barber = context().actorOf(Props.create(Barber.class));

    }

    @Override
    public Receive createReceive() {
        return null;
    }
}
