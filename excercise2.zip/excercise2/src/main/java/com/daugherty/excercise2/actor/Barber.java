package com.daugherty.excercise2.actor;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import com.daugherty.excercise2.messages.*;

/**
 * Created by MMJ1112 on 11/14/2017.
 */
public class Barber extends AbstractActor {

    private LoggingAdapter log = Logging.getLogger(getContext().getSystem(), this);

    @Override
    public AbstractActor.Receive createReceive() {
        //To-Do implement cutting hair recieve action, calls cutHair. assume barber takes 3 seconds to cut hair
        return null;
    }


}

