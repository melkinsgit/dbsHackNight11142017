

import akka.actor.*;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;


public class Pi {

    public static void main(String[] args) {
        Pi pi = new Pi();
        pi.calculate(4, 10000, 10000);
    }


    private void calculate(final int nrOfWorkers,
                           final int nrOfElements,
                           final int nrOfMessages) {

        Config conf = ConfigFactory.load();
        ActorSystem system = ActorSystem.create("PiSystem", conf);
        Props listener_props = Props.create(PiListener.class);
        final ActorRef listener = system.actorOf(listener_props, "listener_actor");

        Props master_props = Props.create(
                PiMaster.class, nrOfWorkers, nrOfMessages, nrOfElements, listener);
        final ActorRef master = system.actorOf(master_props, "master_actor");

        master.tell("calculate", null);
    }
}

