public  class Work {
    private final int start;
    private final int nrOfElements;

    Work(int start, int nrOfElements) {
        this.start = start;
        this.nrOfElements = nrOfElements;
    }

    int getStart() {
        return start;
    }

    int getNrOfElements() {
        return nrOfElements;
    }
}
