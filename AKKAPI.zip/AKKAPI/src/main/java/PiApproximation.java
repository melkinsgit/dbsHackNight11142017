import scala.concurrent.duration.Duration;

public  class PiApproximation {
    private final double pi;
    private final Duration duration;

    PiApproximation(double pi, Duration duration) {
        this.pi = pi;
        this.duration = duration;
    }

    double getPi() {
        return pi;
    }

    Duration getDuration() {
        return duration;
    }
}