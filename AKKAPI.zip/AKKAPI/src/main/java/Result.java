public class Result {
    private final double value;

    Result(double value) {
        this.value = value;
    }

    double getValue() {
        return value;
    }
}
